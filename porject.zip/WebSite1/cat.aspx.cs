﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class cat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string cat_id = Request.QueryString["cat_id"];
        string constr = ConfigurationManager.ConnectionStrings["dd"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM posts WHERE cat_id = "+cat_id+"", con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        ListView1.DataSource = dt;
        ListView1.DataBind();
    }
    protected void ListView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}