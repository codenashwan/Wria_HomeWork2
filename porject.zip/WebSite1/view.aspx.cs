﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;


public partial class view : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string postid = Request.QueryString["post_id"];
        string constr = ConfigurationManager.ConnectionStrings["dd"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM posts p JOIN cat c ON p.cat_id = c.cat_id WHERE p.post_id = "+postid+"", con);

        DataTable dt = new DataTable();
        sda.Fill(dt);
        ListView1.DataSource = dt;
        ListView1.DataBind();
       
    }
}