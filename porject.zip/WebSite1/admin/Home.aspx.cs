﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
using System.IO;
public partial class admin_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string constr = ConfigurationManager.ConnectionStrings["dd"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM posts", con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        ListView1.DataSource = dt;
        ListView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string photo = Path.GetFileName(FileUpload1.PostedFile.FileName);
        string cat_id = DropDownList1.SelectedValue.ToString(); ;
        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/upload/" + photo));
        string constr = ConfigurationManager.ConnectionStrings["dd"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.Open();
        cmd.CommandText = "INSERT INTO posts (titile,details,photo,cat_id) VALUES (@title , @details,@photo,@cat_id)";
        cmd.Parameters.AddWithValue("@title", TextBox1.Text);
        cmd.Parameters.AddWithValue("@details", TextBox2.Text);
        cmd.Parameters.AddWithValue("@photo", photo);
        cmd.Parameters.AddWithValue("@cat_id", cat_id);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("Home.aspx");
    }
}