﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;
public partial class admin_delete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string post_id = Request.QueryString["id"];


        string constr = ConfigurationManager.ConnectionStrings["dd"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.Open();
        cmd.CommandText = "DELETE FROM posts WHERE post_id = @post_id";
        cmd.Parameters.AddWithValue("@post_id", post_id);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("Home.aspx");

    }
}